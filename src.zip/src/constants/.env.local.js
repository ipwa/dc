/* eslint-disable import/prefer-default-export */

// Copy this file as .env.local.js
// @todo add helpers for other environments

// The Drupal url, without a trailing slash:
// https://example.com
// To be used while debugging in React as a standalone app.
export const DEBUG_URL = 'http://sgs.drupal.docker.localhost:8000';

// The consumer id defined via the Drupal Consumers module
// /admin/config/services/consumer
export const CONSUMER_ID = '';
