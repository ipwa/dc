

const SECOND_QUESTION = [
  {
    label:
      "Someone I care about has memory problems or other possible dementia symptoms",
    value: "A1"
  },
  {
    label: "How to support someone through their assessment for dementia",
    value: "A2"
  },
  {
    label:
      "How to support someone who has recently been diagnosed with dementia",
    value: "A3"
  },
  {
    label:
      "Supporting someone who has been living with dementia for a while",
    value: "A4"
  }
]
export const SECOND_QUESTION_DATA = {
  "A1": {
    questions: SECOND_QUESTION,
    label: "What do you need help with?"
  },
  "A2": {
    questions: SECOND_QUESTION ,
    label: "What do you need help with?"
  }
}
