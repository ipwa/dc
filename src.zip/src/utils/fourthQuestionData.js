const FOURTH_QUESTION_LEFT = [
    {
      label: "Dealing with dementia symptoms",
      value: "A1"
    },
    {
      label: "Making the home dementia friendly",
      value: "A2"
    },
    {
      label: "Legal and financial planning",
      value: "A3"
    },
    {
      label: "Staying active and involved",
      value: "A4"
    },
    {
      label: "How to get more help and support",
      value: "A5"
    }
  ]
  const FOURTH_QUESTIONS_RIGHT = [
    {
      label: "How later stage dementials affects behavior and emotions",
      value: "A1"
    },
    {
      label: "Health and personal care for someone with dementia",
      value: "A2"
    },
    {
      label: "Making decisions for the person with dementia",
      value: "A3"
    },
    {
      label: "Care options including how to choose a care home",
      value: "A4"
    },
    {
      label: "Legal and financial planning",
      value: "A5"
    }
  ]
 export const FOURTH_QUESTIONS_DATA = {
    "A1": {
      questions: FOURTH_QUESTION_LEFT,
      label: "Which topics are you interested in?"
    },
    "A2": {
      questions: FOURTH_QUESTIONS_RIGHT,
      label: "Which topics are you interested in?"
    }
  }
