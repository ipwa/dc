import { FIRST_QUESTIONS_DATA } from "./firstQuestionData";
import { SECOND_QUESTION_DATA } from "./secondQuestionData";
import { SECOND_PART_QUESTION_DATA } from "./secondPartQuestionData";
import { THIRD_QUESTION_DATA } from "./thirdQuestionData";
import { FOURTH_QUESTIONS_DATA } from "./fourthQuestionData";

export const DATA_QUESTIONS = {
  firstQuestion: FIRST_QUESTIONS_DATA,
  secondQuestion: SECOND_QUESTION_DATA,
  secondPartQuestion: SECOND_PART_QUESTION_DATA,
  thirdQuestion: THIRD_QUESTION_DATA,
  fourthQuestion: FOURTH_QUESTIONS_DATA
};

const getQuestionInitial = (nameQuestion, answer, acc, values) => {
  const question = DATA_QUESTIONS[nameQuestion][answer].questions
    .filter(question => question.value === values[nameQuestion])
    .pop();
  if (question) {
    acc[nameQuestion] = {
      //...question,
      question: DATA_QUESTIONS[nameQuestion][answer].label,
      answer: question.label
    };
  }
  return acc;
};

const getAnswerIndex = (nameQuestion, valuesFinal) => {
  const ANSWER_INDEX = {
    firstQuestion: "A1",
    secondQuestion: valuesFinal["firstQuestion"],
    secondPartQuestion: valuesFinal["firstQuestion"],
    thirdQuestion: valuesFinal["firstQuestion"],
    fourthQuestion: valuesFinal["thirdQuestion"]
  };
  return ANSWER_INDEX[nameQuestion];
};

export const getAnswerAndQuestion = values => {
  const result = Object.keys(values)
    .filter(nameQuestion => values[nameQuestion] !== "")
    .reduce((acc, nameQuestion) => {
      const answerIndex = getAnswerIndex(nameQuestion, values);
      acc = getQuestionInitial(nameQuestion, answerIndex, acc, values);
      return acc;
    }, {});
  console.log("values result", result, values);
  return result;
};
//getAnswerAndQuestion(FAKE);
