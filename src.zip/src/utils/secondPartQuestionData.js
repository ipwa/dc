const SECOND_PART_QUESTION = [
    {
      label: "I just know it's dementia",
      value: "A1"
    },
    {
      label: "Alzheimer's disease",
      value: "A2"
    },
    {
      label: "Vascular dementia",
      value: "A3"
    },
    {
      label: "Mixed dementia",
      value: "A4"
    },
    {
      label: "Dementia with Lewy bodies",
      value: "A5"
    },
    {
      label: "Frontotemporal dementia (FTD)",
      value: "A6"
    },
    {
      label: "Young-onset dementia (before 65)",
      value: "A7"
    },
    {
      label: "Posterior cortical atrophy (PCA)",
      value: "A8"
    },
    {
      label: "Alcohol-related brain damage",
      value: "A9"
    },
    {
      label: "Rarer types of dementia",
      value: "A10"
    }
  ]
  export const SECOND_PART_QUESTION_DATA = {
    "A1": {
      questions: SECOND_PART_QUESTION,
      label: "What type of dementia do you have?"
    },
    "A2": {
      questions: SECOND_PART_QUESTION,
      label: "What type of dementia does the person have?"
    }
  };
