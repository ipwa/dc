import React from "react";
import { Formik, Field } from "formik";
import {
  Route,
  NavLink,
  BrowserRouter as Router,
  Switch
} from "react-router-dom";
import SRRecieved from "./SRRecieved";

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));

const required = value => (value ? undefined : "Required");

const Error = ({ name }) => (
  <Field
    name={name}
    render={({ form: { touched, errors } }) =>
      touched[name] && errors[name] ? <span className="form__error">{errors[name]}</span> : null
    }
  />
);

class Wizard extends React.Component {
  static Page = ({ children, parentState }) => {
    return children(parentState);
  };

  constructor(props) {
    super(props);
    this.state = {
      page: 0,
      values: props.initialValues
    };
  }

  next = values =>
    this.setState(state => ({
      page: Math.min(state.page + 1, this.props.children.length - 1),
      values
    }));

  previous = () =>
    this.setState(state => ({
      page: Math.max(state.page - 1, 0)
    }));

  validate = values => {
    const activePage = React.Children.toArray(this.props.children)[
      this.state.page
    ];
    return activePage.props.validate ? activePage.props.validate(values) : {};
  };

  handleSubmit = (values, bag) => {
    const { children, onSubmit } = this.props;
    const { page } = this.state;
    const isLastPage = page === React.Children.count(children) - 1;
    if (isLastPage) {
      return onSubmit(values, bag);
    } else {
      this.next(values);
      bag.setSubmitting(false);
    }
    const { history } = this.props
  };

  render() {
    const { children } = this.props;
    const { page, values } = this.state;
    const activePage = React.Children.toArray(children)[page];
    const isLastPage = page === React.Children.count(children) - 1;
    return (
      <Formik
        initialValues={values}
        enableReinitialize={false}
        validate={this.validate}
        onSubmit={this.handleSubmit}
        render={props => (
          <form className="form" onSubmit={props.handleSubmit}>
            {React.cloneElement(activePage, { parentState: { ...props } })}
            <div className="form__buttons">
              {page > 0 && (
                <button type="button" className="button hide-button" onClick={this.previous}>
                  « Previous
                </button>
              )}

              {!isLastPage && <button type="submit" className="button">Request callback</button>}
              {isLastPage && (
                <button type="submit" className="button hide-button" disabled={props.isSubmitting}>
                  Submit
                </button>
              )}
            </div>

          </form>
        )}
      />
    );
  }
}

class ButtonParent extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      condition: false
    }
    this.handleClick = this.handleClick.bind(this)
  }
  handleClick() {
    this.setState({
      condition: !this.state.condition
    })
  }
  render() {
    return (
      <ButtonChild
        className={ this.state.condition ? "toggled" : "hide" }
        toggleClassName={ this.handleClick }
      >
        Add a secondary phone number, like a landline.
      </ButtonChild>
    )
  }
}

class ButtonChild extends React.Component {
  render() {
    return (
      <div className={ this.props.className }>
        <a onClick={ this.props.toggleClassName }>{ this.props.children }</a>
              <Field
                name="phone2"
                component="input"
                type="text"
                placeholder="Type your phone number here"
              />
      </div>
    )
  }
}

const SRForm = () => (
  <div className="SRForm">
    <Wizard
      initialValues={{
        firstName: "",
        phone: "",
        phone2: "",
        postcode: "",
        email: "",
        language: ""
      }}
      onSubmit={(values, actions) => {
        sleep(300).then(() => {
          window.alert(JSON.stringify(values, null, 2));
          this.props.history.push('/sr-recieved');
          actions.setSubmitting(false);
        });
      }}
    >
      <Wizard.Page
        validate={values => {
          const errors = {};
          return errors;
        }}
      >
        {props => (
          <React.Fragment>
            <h2 className="form__title has-text-centered title is-2">
              Speak with a Dementia Adviser
            </h2>
            <p className="form__intro">We just need a few details before an adviser can call you back.</p>
            <div className="form__element">
              <label htmlFor="firstName">Your first and last name<span className="req">*</span></label>
              <Field
                name="firstName"
                component="input"
                type="text"
                placeholder="Start typing your name here"
                validate={required}
                required
              />
              <Error name="firstName" />
            </div>
            <div className="form__element">
              <label htmlFor="phone">Your phone number<span className="req">*</span></label>
              <p className="form__element-description">
                A mobile number can help us to reach you first-time.
              </p>
              <Field
                name="phone"
                component="input"
                type="text"
                placeholder="Type your phone number here"
                validate={required}
                required
              />
              <Error name="phone" />
              <ButtonParent />
            </div>
            <div className="form__element">
              <label htmlFor="postcode">Your postcode<span className="req">*</span></label>
              <p className="form__element-description">
                This is so we can connect you with local services.
              </p>
              <Field
                name="postcode"
                component="input"
                type="text"
                placeholder="Type your postcode here"
                validate={required}
                required
              />
              <Error name="postcode" />
            </div>
            <div className="form__element">
              <label htmlFor="email">Your email</label>
              <p className="form__element-description">
                This helps us set-up your call and to support you.
              </p>
              <Field
                name="email"
                component="input"
                type="email"
                placeholder="e.g. joe@alzheimers.org.uk"
                validate={required}
              />
              <Error name="email" />
            </div>
            <div className="form__element form__radio">
              <label htmlFor="options">Your preferred language<span className="req">*</span></label>
              <p className="form__element-description">
                This tells our advisors which language to use when calling.
              </p>
              <div className="form__option">
                <Field type="radio" id="language1" name="language" value="english" required />
                <label className="form__radio-label" htmlFor="language1">
                  English
                </label>
              </div>
              <div className="form__option">
                <Field type="radio" id="language2" name="language"  value="welsh" />
                <label className="form__radio-label" htmlFor="language2">
                  Welsh
                </label>
              </div>
            </div>
            <div className="form__consent">
              <h1 className="title is-5">Consent for your callback</h1>
              <p>By continuing this form, you confirm that you understand Alzheimer's Society will be sent details about the information you entered and content you viewed. This is to support your phone call with a Dementia Adviser.</p>
              <p>Alzheimer's Society promise never to sell or share your data with anyone. All information and data will be stored in accordance to our organisation's data privacy and GDPR guidelines.</p>
              <p>&nbsp;</p>
            </div>
          </React.Fragment>
        )}
      </Wizard.Page>
      <Wizard.Page
        validate={values => {
          const errors = {};
          return errors;
        }}
      >
        {props => (
          <React.Fragment>
            <div>
              <SRRecieved />
            </div>
          </React.Fragment>
        )}
      </Wizard.Page>
    </Wizard>
  </div>
);

export default SRForm;
