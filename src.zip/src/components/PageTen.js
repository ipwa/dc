import React, { Fragment } from 'react';
import Hero from "./Hero";
import Result from "./Result";

const PageTen = () => {
  return (
    <div>
      <Hero
        title={<Fragment><h2 className="has-text-centered title is-2">Your results</h2></Fragment>}
        body={<Fragment><p>Here's information we think will be useful for you based on what you've told us.</p></Fragment>}
      />
      <p>&nbsp;</p><p>&nbsp;</p>
      <div className="wrapper">
        <h3 className="title is-3">Need to know</h3>
        <div className="grid">
          <Result
            title={"The later stages of dementia"}
            url={"https://www.alzheimers.org.uk/about-dementia/symptoms-and-diagnosis/how-dementia-progresses/later-stages"}
          />
        </div>
        <h3 className="title is-3">Advice and stories:</h3>
        <div className="grid">
          <Result
            title={"Care at home or care home? A decision for all families"}
            url={"https://www.alzheimers.org.uk/blog/care-home-or-care-home-decision-all-families"}
          />
          <Result
            title={"Guilt and dementia: How to manage guilty feelings as a carer"}
            url={"https://www.alzheimers.org.uk/blog/guilt-dementia-how-manage-guilty-feelings-carer"}
          />
          <Result
            title={"Finding support online if you're caring for a person experiencing the later stages of dementia"}
            url={"https://www.alzheimers.org.uk/get-support/publications-and-factsheets/dementia-together-magazine/finding-support-online"}
          />
        </div>
      </div>
    </div>
  );
};

export default PageTen;
