import React, { Fragment } from 'react';
import Hero from "./Hero";

class SRReceived extends React.Component {
  render() {
    return (
      <div>
        <Hero
          title={<Fragment><h2 className="has-text-centered title is-2">We've recieved your callback request</h2></Fragment>}
          body={<Fragment><p>One of our adviser will give you a call within the next 3 working days.</p></Fragment>}
        />
        <p>&nbsp;</p><p>&nbsp;</p>
        <div className="wrapper">
          <h3 className="title is-3">What happens next</h3>
          <ul className="StepProgress">
            <li className="StepProgress-item is-done"><h5 className="title is-5">Today</h5>
              <p>Your callback request has been received. You don't need to do anything else, although you can: <a href="">Print the information you've told us</a> <a href="">Email the information you've told us</a></p>
            </li>
            <li className="StepProgress-item"><h5 className="title is-5">Ahead of your call</h5>
              <p>If you notice a situation getting worse, we recommend speaking with you GP or <a href="">using 111 for advice from the NHS.</a></p>
            </li>
            <li className="StepProgress-item"><h5 className="title is-5">When we call you</h5>
              <p>One of our specialist Dementia Advisers will call you within three working days.</p>
              <p>Just so you know your Advisor will call from a number beginning with 0338.</p>
            </li>
            <li className="StepProgress-item is-last"><h5 className="title is-5">After your call</h5>
              <p>Receive optional 'keeping in touch' calls from a Dementia Adviser every six months, or at an interval of your choosing.</p>
            </li>
          </ul>
        </div>
      </div>
    );
  }
}

export default SRReceived;
