import React, { Fragment } from 'react';
import { NavLink } from "react-router-dom";
import Hero from "./Hero";

class App extends React.Component {
  render() {
    return (
      <div>
        <Hero
          title={<Fragment><h2 className="has-text-centered title is-2">Dementia Connect</h2></Fragment>}
          body={<Fragment><p>Find support and information tailored to you.</p><NavLink className="button" to="/sgs">Start</NavLink></Fragment>}
        />
        <p>&nbsp;</p><p>&nbsp;</p>
        <div className="wrapper">
          <h3 className="title is-3">What happens next</h3>
          <ul className="StepProgress is-numeric">
            <li className="StepProgress-item"><h5 className="title is-5">Tell us who you'd like to support</h5>
              <p>We can tailor support to people living with dementia or carers.</p>
            </li>
            <li className="StepProgress-item"><h5 className="title is-5">Tell us what you'd like support with</h5>
              <p>Help us narrow down our support by telling us what topic you're most intertested in.</p>
            </li>
            <li className="StepProgress-item"><h5 className="title is-5">Results</h5>
              <p>One of our specialist Dementia Advisers will call you within three working days.</p>
              <p>Just so you know your Advisor will call from a number beginning with 0338.</p>
            </li>
            <li className="StepProgress-item is-last"><h5 className="title is-5">Request a call back from an adviser (optional)</h5>
              <p>Receive optional 'keeping in touch' calls from a Dementia Adviser every six months, or at an interval of your choosing.</p>
            </li>
          </ul>
        </div>
        <div className="referral">
          <h3 className="title is-3">Are you a doctor or healthcare professional?</h3>
          <NavLink className="referral__link" to="/sr">Make referral</NavLink>
          <p>We provide a separate callback service for healthcare professionals.</p>
        </div>
      </div>
    );
  }
}

export default App;
