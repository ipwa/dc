import React, { Fragment } from 'react';
import Hero from "./Hero";
import Result from "./Result";

const PageFour = () => {
  return (
    <div>
      <Hero
        title={<Fragment><h2 className="has-text-centered title is-2">Your results</h2></Fragment>}
        body={<Fragment><p>Here's information we think will be useful for you based on what you've told us.</p></Fragment>}
      />
      <p>&nbsp;</p><p>&nbsp;</p>
      <div className="wrapper">
        <h3 className="title is-3">Need to know</h3>
        <div className="grid">
          <Result
            title={""}
            url={""}
          />
        </div>
        <h3 className="title is-3">Advice and stories:</h3>
        <div className="grid">
          <Result
            title={"Memory and migration: ‘I have dementia, but I still remember my past’"}
            url={"https://www.alzheimers.org.uk/blog/memory-migration-dementia-remember-my-past"}
          />
          <Result
            title={"Dear Alzheimer’s: Letters from a man living with dementia"}
            url={"https://www.alzheimers.org.uk/blog/dear-alzheimers-keith-oliver-letters"}
          />
          <Result
            title={"Alison challenges people's perception of dementia with her story"}
            url={"https://www.alzheimers.org.uk/blog/alison-challenges-peoples-perception-dementia-her-story"}
          />
        </div>
      </div>
    </div>
  );
};

export default PageFour;
