import React from 'react';
import ReactDOM from 'react-dom';
import {
  Route,
  NavLink,
  BrowserRouter as Router,
  Switch
} from "react-router-dom";
import App from "./components/App";
import SGSForm from "./components/SGSForm";
import SGSResults from "./components/SGSResults";
import SRForm from "./components/SRForm";
import SRRecieved from "./components/SRRecieved";
import api from './utils/api';

const routing = (
  <Router>
    <div className="container">
    <div className="columns is-centered">
    <div className="column is-12">
      <Switch>
        <Route path="/sr" component={SRForm} />
        <Route path="/sr-recieved" component={SRRecieved} />
        <Route path="/sgs" component={SGSForm} />
        <Route path="/sgs-results" component={SGSResults} />
      </Switch>
    </div>
    </div>
    </div>
  </Router>
);

const appContainer = document.getElementById(api.getAppContainerId());

if (appContainer) {
  ReactDOM.render(routing, appContainer);
}
